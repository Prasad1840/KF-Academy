import React from "react";

export default function HomePage() {
  return (
   <section className="relative h-screen overflow-hidden">
  {/* ✅ Zooming background image */}
  <div className="absolute inset-0 z-0 bg-cover bg-center bg-no-repeat animate-zoom scale-105" style={{ backgroundImage: "url('/assets/working-people.jpg')" }} />

  {/* Content */}
  <div className="relative z-10 flex flex-col justify-center items-center h-full text-white text-center px-4">
    <h1 className="text-5xl md:text-6xl font-extrabold drop-shadow-xl">
      Welcome to Our Site
    </h1>
    <p className="text-lg md:text-xl mt-4 max-w-xl drop-shadow-lg">
      Innovating for a better future with seamless experiences.
    </p>
  </div>
</section>

  );
}
